# NetSage AI Dashboard

## Run
Install:
`pip install streamlit pandas`

Then:
`streamlit run dashboard.py`

## Shows
- Total cases
- Reviewed / pending
- Accepted / edited / rejected
- AI-human agreement
- Issue type distribution
- Severity distribution
- AI confidence
- Case explorer

The dashboard intentionally does not fabricate an agreement rate before actual
human review is entered.
