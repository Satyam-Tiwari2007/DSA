# NetSage AI — Group Information

## Group Members

1. **Shushant Tiwari** — 3CSE24 — 2410031232
2. **Satyam Tiwari** — 2CSE35 — 25SCS1003005312

## Division of Work

- **Shushant Tiwari — AI Architecture, Prompt Engineering, Dataset & AI Evaluation**
  - Structured the evidence-first AI troubleshooting workflow.
  - Designed the diagnostic prompt and structured output contract.
  - Organized/validated the 40-case dataset and evaluation comparison.
  - Worked on AI-result consistency, architecture and technical documentation.

- **Satyam Tiwari — Rule Checker, Application, Dashboard, Responsible AI, Integration & QA**
  - Developed/validated deterministic network rule checks.
  - Worked on the Streamlit application and evaluation dashboard.
  - Maintained the human-review and Responsible AI workflow.
  - Performed integration, testing, QA and demonstration preparation.

The two members' individual summary documents in `10_Documentation` describe their specific primary contributions.
