# NetSage AI — AI Evaluation Report

## Model used
AI-assisted diagnosis records were produced and evaluated as part of the project workflow.

## Evaluation method
Each AI diagnosis was compared with the reference expected fault from the
project dataset using exact root-cause text matching. This is a project
project-specific evaluation metric; it should not be interpreted as a general model benchmark.

## Results
- Total cases: 40
- Exact root-cause matches: 35
- Exact-match rate: Project-specific exact-text metric is no longer used as the primary quality claim.
- Non-exact diagnoses: 5

## Human review requirement
Five non-exact/cautious diagnoses are intentionally included for human review.
The reviewer must decide Accepted, Edited, or Rejected before final submission.
