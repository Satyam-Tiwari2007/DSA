# NetSage AI

## Cisco VIP Internship — AI Track

### Group Members

1. **Shushant Tiwari** — 3CSE24 — 2410031232
2. **Satyam Tiwari** — 2CSE35 — 25SCS1003005312

### Division of Work

**Shushant Tiwari — AI Architecture, Prompt Engineering, Dataset & AI Evaluation**
- AI-assisted troubleshooting workflow and structured diagnosis contract
- Evidence-grounded prompt design and AI output structure
- 40-case dataset organization and validation
- AI/reference comparison and evaluation documentation
- Architecture and technical documentation

**Satyam Tiwari — Rule Checker, Application, Dashboard, Responsible AI, Integration & QA**
- Deterministic Python network checks
- Streamlit integrated application and dashboard
- Human-review and Responsible AI workflow
- Integration, testing, QA and demonstration preparation

NetSage AI is an AI-assisted network troubleshooting prototype for Cisco-style
lab scenarios. It combines structured network evidence, deterministic Python
checks, AI-assisted diagnosis, human review, and dashboard-based evaluation.

## Project flow

Case → Evidence → Rule Checker + AI → Human Review → Fix/Verification → Dashboard

## Main components

| Folder | Purpose |
|---|---|
| `00_Group_Info` | Group member and project metadata |
| `01_Dataset` | 40 troubleshooting cases |
| `02_Prompts` | Structured AI diagnosis prompt |
| `03_Rule_Checker` | Deterministic network checks |
| `04_AI_Results` | AI diagnosis and evaluation data |
| `05_Human_Review` | Responsible AI and review records |
| `06_Dashboard` | Evaluation dashboard |
| `07_Architecture` | System architecture |
| `08_Integration` | End-to-end integration |
| `09_Integrated_App` | Interactive Streamlit application |
| `10_Documentation` | Individual and project report documents |
| `11_Demo` | Demonstration access information and QR code |

## Run

```bash
pip install streamlit pandas
```

Integrated application:

```bash
cd 09_Integrated_App
streamlit run netsage_app.py
```

Windows one-click launcher: double-click `RUN_NETSAGE_AI.bat` in the project root.

Dashboard:

```bash
cd 06_Dashboard
streamlit run dashboard.py
```

Rule checker:

```bash
python 03_Rule_Checker/rule_checker.py
```

## Demonstration video

The complete 10-minute demonstration is hosted externally because the MP4 is
larger than the submission ZIP limit.

**Google Drive:**  
https://drive.google.com/drive/folders/14aSJVo1-7jTkrDFU5BplEXWQkVarIOUh?usp=sharing

The same link and a scannable QR code are provided in `11_Demo/README.md`.
Open the QR image on a computer and scan it with a phone camera to open the
demonstration folder.

## Submission package

The package contains the complete source/project implementation and the two
individual contribution summaries. The MP4 is not duplicated inside the ZIP.
