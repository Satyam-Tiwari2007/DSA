# NetSage AI — Project Demonstration

## 10-minute demonstration video

The complete project demonstration is hosted in the Google Drive folder below.

**Drive link:**  
https://drive.google.com/drive/folders/14aSJVo1-7jTkrDFU5BplEXWQkVarIOUh?usp=sharing

## QR code

Scan `NetSage_AI_Demo_QR.png` with a phone camera or QR-scanning app to open
the same Google Drive folder.

**File:** `NetSage_AI_Demo_QR.png`

## Demonstration flow

1. Introduce the network troubleshooting problem.
2. Show the NetSage AI architecture.
3. Select a troubleshooting case.
4. Display symptom, topology and Cisco show-command evidence.
5. Run the deterministic rule checker.
6. Display the structured AI diagnosis.
7. Demonstrate the human-review gate.
8. Show the proposed correction and verification approach.
9. Open the dashboard and explain the evaluation views.
10. End with the external demonstration-video access link.

The MP4 is intentionally hosted externally and is not duplicated inside this ZIP.


## Project Demonstration Video

Complete 10-minute demonstration video:
https://drive.google.com/drive/folders/14aSJVo1-7jTkrDFU5BplEXWQkVarIOUh?usp=sharing

The QR code in this folder points to the same Drive location.
